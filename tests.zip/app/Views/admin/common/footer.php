<!-- Main Footer -->
<footer class="main-footer">
    <strong>Copyright &copy; <a href="http://vycabs.com/">VYCab</a></strong>
    Rewamp.
    <div class="float-right d-none d-sm-inline-block">
        <b>Version</b> 1.0.0
    </div>
</footer>
</div>
<!-- ./wrapper -->

<!-- AdminLTE App -->
<script src="<?php echo base_url('assets/js/adminlte.js'); ?>"></script>
</body>

</html>